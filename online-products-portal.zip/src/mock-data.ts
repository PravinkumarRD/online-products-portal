export const ProductsMockData = [
  {
    productId: 3478,
    productName: 'Blue T-Shirt',
    price: 470,
    availableStock: 40,
    category: 'Male T-Shirts',
    availableSince: new Date(),
    discount: 23,
    color: 'Blue',
    image: '../images/blue-t-shirt.jpg',
    company: 'ZX Pvt. Ltd.'
  },
  {
    productId: 3479,
    productName: 'Maroon T-Shirt',
    price: 450,
    availableStock: 30,
    category: 'Male T-Shirts',
    availableSince: new Date(),
    discount: 20,
    color: 'Maroon',
    image: '../images/maroon-t-shirt.jpg',
    company: 'ZX Pvt. Ltd.'
  },
  {
    productId: 3480,
    productName: 'Gray T-Shirt',
    price: 490,
    availableStock: 60,
    category: 'Male T-Shirts',
    availableSince: new Date(),
    discount: 12,
    color: 'Gray',
    image: '../images/gray-t-shirt.jpg',
    company: 'ZX Pvt. Ltd.'
  },
  {
    productId: 3481,
    productName: 'Black T-Shirt',
    price: 500,
    availableStock: 10,
    category: 'Male T-Shirts',
    availableSince: new Date(),
    discount: 10,
    color: 'Black',
    image: '../images/black-t-shirt.jpg',
    company: 'ZX Pvt. Ltd.'
  }
];
