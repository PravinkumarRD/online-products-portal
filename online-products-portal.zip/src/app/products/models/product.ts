export class Product {
  productId: number;
  productName: string;
  price: number;
  availableStock: number;
  category: string;
  availableSince: Date;
  discount: number;
  color: string;
  image: string;
  company: string;
}
