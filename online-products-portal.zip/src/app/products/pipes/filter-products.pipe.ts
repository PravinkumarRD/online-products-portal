import { Pipe, PipeTransform } from '@angular/core';

import { Product } from "../models/product";

@Pipe({
  name: 'filterProducts'
})
export class FilterProductsPipe implements PipeTransform {

  transform(value: Product[], ...args: string[]): Product[] {
    if (!value) return value;
    let filterString: string = args[0] ? args[0] : "";
    return value.filter((product) => product.productName.toLocaleLowerCase().includes(filterString));
  }

}
