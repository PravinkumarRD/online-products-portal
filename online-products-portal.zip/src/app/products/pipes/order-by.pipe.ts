import { Pipe, PipeTransform } from '@angular/core';

import { Product } from "../models/product";

@Pipe({
  name: 'orderBy'
})
export class OrderByPipe implements PipeTransform {

  transform(value: Product[], ...args: any[]): Product[] {
    if (!value) return value;
    let colName: string = args[0];
    let sortOrder: number = Number.parseInt(args[1]);
    if (sortOrder == 0) {
      return value.sort(function (product1, product2) {
        if (product1[colName] < product2[colName]) return -1;
        if (product1[colName] > product2[colName]) return 1;
        return 0;
      });
    }
    else {
      return value.sort(function (product1, product2) {
        if (product1[colName] < product2[colName]) return -1;
        if (product1[colName] > product2[colName]) return 1;
        return 0;
      }).reverse();
    }
  }

}
