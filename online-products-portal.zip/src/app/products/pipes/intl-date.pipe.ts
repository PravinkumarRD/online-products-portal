import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'intlDate'
})
export class IntlDatePipe implements PipeTransform {

  transform(value: Date, ...args: string[]): string {
    if (!value) return value;
    let locale: string = args[0] ? args[0] : "us-EN";
    return new Intl.DateTimeFormat(locale, {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    }).format(new Date(value));
  }

}

//|intlDate:'fr-FR'