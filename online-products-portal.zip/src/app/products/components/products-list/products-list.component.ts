import { Component, OnInit } from '@angular/core';

import { ProductsMockData } from "../../../../mock-data";

import { Product } from "../../models/product";

@Component({
  selector: 'wph-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent implements OnInit {

  constructor() { }
  public title: string = "Welcome To WebPoCHub Products!";
  public subTitle: string = "All the products available for Sale!";
  public isDisabled: boolean = false;
  public products: Product[] = ProductsMockData;
  public selectedProduct: Product;
  public searchChars: string = "";
  public columnName: string = "";
  public direction: boolean = true;
  public sortOrder: number = -1;
  public currentPage: number = 1;

  public columnClick(colName: string): void {
    if (this.columnName == colName && this.direction == false) {
      this.sortOrder = 1;
      this.direction = true;
    } else {
      this.direction = false;
      this.sortOrder = 0;
    }
    this.columnName = colName;
  }

  public onProductSelection(product: Product): void {
    this.selectedProduct = product;
  }
  ngOnInit(): void {
  }
  public changeTitle(): void {
    this.title = "Welcome To WebPoCHub Products from India!";
  }

}
