import { Component, OnInit, Input } from '@angular/core';

import { Product } from "../../models/product";

@Component({
  selector: 'wph-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor() { }

  public title: string = "Details Of - ";
  @Input() public product: Product;

  ngOnInit(): void {
  }

}
