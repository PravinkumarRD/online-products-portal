import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { NgxPaginationModule } from "ngx-pagination";

import { ProductsListComponent } from './components/products-list/products-list.component';
import { ProductDetailsComponent } from './components/product-details/product-details.component';

import { IntlDatePipe } from './pipes/intl-date.pipe';
import { FilterProductsPipe } from './pipes/filter-products.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';

@NgModule({
  declarations: [
    ProductsListComponent,
    ProductDetailsComponent,
    IntlDatePipe,
    FilterProductsPipe,
    OrderByPipe
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgxPaginationModule
  ],
  exports:[
    ProductsListComponent
  ]
})
export class ProductsModule { }
